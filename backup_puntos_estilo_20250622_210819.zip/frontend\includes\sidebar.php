<div class="sidebar">
    <div class="user-info">
        <p>¡Hola 👋!</p>
        <p>Hoy sumas:</p>
        <p><?php echo htmlspecialchars($total_puntos); ?> pts</p>
    </div>
    <ul class="menu">
        <li>Inicio</li>
        <li>Mis consumos</li>
        <li>Mis bonos</li>
        <li>Mis referidos</li>
        <li>Retos</li>
        <li>Catálogo</li>
        <li>Aliados</li>
        <li>Mapas</li>
        <li>Mis datos</li>
        <li><a href="logout.php">Cerrar Sesión</a></li>
    </ul>
</div>
