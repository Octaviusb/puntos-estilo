<footer class="footer">
  <div class="footer-box">
    <div class="footer-column">
      <h2>Contacto</h2>
      <p><strong>Dirección:</strong> Calle Falsa 123, Bogotá</p>
      <p><strong>Teléfono:</strong> +57 555-555-555</p>
      <p><strong>Email:</strong> contacto@puntosestilo.com</p>
      <p><strong>Horario:</strong> Lunes a Domingo<br>6:00 AM - 10:00 PM</p>
    </div>

    <div class="footer-column">
      <h2>Puntos Estilo</h2>
      <p>Acumula puntos en cada compra y canjéalos por increíbles beneficios.</p>
    </div>

    <div class="footer-column">
      <h2>Síguenos</h2>
      <div class="social-links">
        <a href="#" class="social-link">Facebook</a>
        <a href="#" class="social-link">Instagram</a>
        <a href="#" class="social-link">Twitter</a>
      </div>
    </div>
  </div>

  <div class="footer-bottom">
    <p>&copy; 2024 Puntos Estilo. Todos los derechos reservados.</p>
  </div>
</footer>
