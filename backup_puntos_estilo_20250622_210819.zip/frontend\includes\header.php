<div class="header">
    <div class="status">
        <div class="status-item">
            <h3>Última acumulación</h3>
            <p>Aún no has ganado puntos<br>Por cada compra en nuestras<br>estaciones ganas puntos.</p>
        </div>
        <div class="status-item">
            <h3>Última redención</h3>
            <p>Aún no registramos redención<br>Te invitamos a canjear tus puntos en<br>nuestro catálogo</p>
        </div>
    </div>
</div>
