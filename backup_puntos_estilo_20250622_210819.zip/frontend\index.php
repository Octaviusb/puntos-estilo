<?php
// Redirigir al login
header('Location: login.php');
exit();