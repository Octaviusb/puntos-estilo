-- Crear la base de datos si no existe
CREATE DATABASE IF NOT EXISTS mi_proyecto;
USE mi_proyecto;

-- Tabla de usuarios
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    correo VARCHAR(100) NOT NULL UNIQUE,
    contraseña VARCHAR(255) NOT NULL,
    puntos INT DEFAULT 0,
    avatar VARCHAR(255) DEFAULT NULL,
    rol ENUM('usuario', 'admin') DEFAULT 'usuario',
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ultimo_acceso TIMESTAMP NULL,
    estado BOOLEAN DEFAULT TRUE
);

-- Tabla de transacciones
CREATE TABLE IF NOT EXISTS transacciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    tipo ENUM('acumulacion', 'redencion') NOT NULL,
    puntos INT NOT NULL,
    descripcion TEXT,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Tabla de productos
CREATE TABLE IF NOT EXISTS productos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    imagen VARCHAR(255),
    puntos INT NOT NULL,
    destacado BOOLEAN DEFAULT FALSE,
    stock INT DEFAULT 0,
    estado BOOLEAN DEFAULT TRUE,
    fecha_creacion TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de mensajes de contacto
CREATE TABLE IF NOT EXISTS mensajes_contacto (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    correo VARCHAR(100) NOT NULL,
    celular VARCHAR(20) NOT NULL,
    mensaje TEXT NOT NULL,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    estado ENUM('nuevo', 'leido', 'respondido') DEFAULT 'nuevo'
);

-- Insertar usuario administrador por defecto
INSERT INTO usuarios (nombre, correo, contraseña, rol) 
VALUES ('Administrador', 'admin@puntosestilo.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin')
ON DUPLICATE KEY UPDATE id=id;

-- Insertar algunos productos de ejemplo
INSERT INTO productos (nombre, descripcion, imagen, puntos, destacado, stock) VALUES
('Perro Altoque', 'Delicioso perro caliente con todos los ingredientes', 'images/perro.jpg', 1450, TRUE, 50),
('Bono Combustible $5.000', 'Bono de combustible por valor de $5.000', 'images/bono-5000.jpg', 1500, TRUE, 100),
('Bono Combustible $1.000', 'Bono de combustible por valor de $1.000', 'images/bono-1000.jpg', 300, TRUE, 200),
('Bono Combustible $10.000', 'Bono de combustible por valor de $10.000', 'images/bono-10000.jpg', 3000, TRUE, 50); 